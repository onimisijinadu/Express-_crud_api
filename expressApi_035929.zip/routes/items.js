import express from "express";

const router = express.Router();
const items = [
  { id: 1, name: "Item 1", description: "Description for Item 1" },
  { id: 2, name: "Item 2", description: "Description for Item 2" },
];

const findItem = (id) => items.find((item) => item.id === parseInt(id));

// GET all items
router.get("/", (req, res) => res.send(items));

// GET item by ID
router.get("/:id", (req, res) => {
  const item = findItem(req.params.id);
  if (!item) return res.status(404).send({ error: "Item not found" });
  res.send(item);
});

// POST create new item
router.post("/", (req, res) => {
  const { name, description } = req.body;
  if (!name || !description)
    return res.status(400).send({ error: "Name and description required" });

  const newItem = { id: items.length + 1, name, description };
  items.push(newItem);
  res.status(201).send(newItem);
});

// PUT update item
router.put("/:id", (req, res) => {
  const item = findItem(req.params.id);
  if (!item) return res.status(404).send({ error: "Item not found" });

  const { name, description } = req.body;
  if (!name || !description)
    return res.status(400).send({ error: "Name and description required" });

  item.name = name;
  item.description = description;
  res.send(item);
});

// DELETE item
router.delete("/:id", (req, res) => {
  const index = items.findIndex((item) => item.id === parseInt(req.params.id));
  if (index === -1) return res.status(404).send({ error: "Item not found" });

  items.splice(index, 1);
  res.send({ message: "Item deleted" });
});

export default router;
